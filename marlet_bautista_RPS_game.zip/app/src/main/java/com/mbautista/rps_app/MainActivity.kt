package com.mbautista.rps_app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import java.util.Random

class MainActivity : AppCompatActivity() {
    private lateinit var userSelectionTextView: TextView
    private lateinit var compSelectionTextView: TextView
    private lateinit var wonLostTieTextView: TextView
    private lateinit var scoreTextView: TextView
    private lateinit var resetButton: Button
    private lateinit var rockButton: ImageButton
    private lateinit var paperButton: ImageButton
    private lateinit var scissorsButton: ImageButton
    private var userScore = 0
    private var compScore = 0
    private val random = Random()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        userSelectionTextView = findViewById(R.id.userSelection)
        compSelectionTextView = findViewById(R.id.computerSelectionTextView)
        wonLostTieTextView = findViewById(R.id.wonLostTieTextView)
        scoreTextView = findViewById(R.id.scoreTextView)
        resetButton = findViewById(R.id.button)
        rockButton = findViewById(R.id.imageButtonRock)
        paperButton = findViewById(R.id.imageButtonPaper)
        scissorsButton = findViewById(R.id.imageButtonScissors)

        resetGame()
    }
    fun resetButton(view: View) {
        resetGame()
    }
    private fun resetGame() {

        wonLostTieTextView.text = ""
        userSelectionTextView.text = ""
        compSelectionTextView.text = ""
        userScore = 0
        compScore = 0
        setScoreTextView(userScore, compScore)

        resetButton.visibility = View.GONE
        rockButton.isEnabled = true
        paperButton.isEnabled = true
        scissorsButton.isEnabled = true

    }
    fun rpsButtonSelected(view: View) {
        val userSelection = view.tag.toString().toInt()
        matchGame(userSelection)
    }

    private fun matchGame(userSelection: Int) {
        val compSelection = random.nextInt(3) + 1

        when {
            userSelection == compSelection -> wonLostTieTextView.text = "Tie"
            (userSelection - compSelection + 3) % 3 == 1 -> {
                userScore++
                wonLostTieTextView.text = "User wins round!"
            }

            else -> {
                compScore++
                wonLostTieTextView.text = "Computer wins round!"
            }
        }

        userSelectionTextView.text = when (userSelection) {
            1 -> "Rock"
            2 -> "Paper"
            else -> "Scissors"
        }
        compSelectionTextView.text = when (compSelection) {
            1 -> "Rock"
            2 -> "Paper"
            else -> "Scissors"
        }

        setScoreTextView(userScore, compScore)
    }

    private fun setScoreTextView(userScore: Int, compScore: Int) {
        scoreTextView.text = "$userScore : $compScore"
        if (userScore >= 10 || compScore >= 10) {
            wonLostTieTextView.text = if (userScore >= 10) "User wins the game!" else "Computer wins the game!"

            rockButton.isEnabled = false
            paperButton.isEnabled = false
            scissorsButton.isEnabled = false
            resetButton.isEnabled = true
            resetButton.visibility = View.VISIBLE
            resetButton.requestLayout()
        }
    }
}